
package model;

import java.io.Serializable;
import repository.CSVSerializable;


public class Receta implements CSVSerializable,Comparable<Receta>,Serializable {
    private int id;
    private String nombre;
    private String autor;
    private TipoReceta tipo;
    
    
    
    public Receta(int id, String nombre, String autor, TipoReceta tipo) {
        this.id = id;
        this.nombre = nombre;
        this.autor = autor;
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Receta{" + "id=" + id + ", nombre=" + nombre + ", autor=" + autor + ", tipo=" + tipo + '}';
    }
    
    
    @Override
    public String toCSV() {
        return id + "," + nombre + "," + autor + "," + tipo;
    }
    
    public static Receta fromCSV(String linea) {
    String[] partes = linea.split(",");
    int id = Integer.parseInt(partes[0]);
    String nombre = partes[1];
    String autor = partes[2];
    TipoReceta tipo = TipoReceta.valueOf(partes[3]);
    return new Receta(id, nombre, autor, tipo);
}

    public TipoReceta getTipo() {
        return tipo;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getAutor() {
        return autor;
    }

    @Override
    public int compareTo(Receta r) {
        return Integer.compare(r.id, this.id);}
    
    
}


package repository;

@FunctionalInterface
public interface CSVSerializable {
    
    String toCSV();
}


package aymojusto.parcial2.pkg322;

import config.RutasArchivos;
import java.io.IOException;
import java.util.List;
import model.Receta;
import model.TipoReceta;
import model.LibroDeRecetas;

public class AymoJustoParcial2322 {

    public static void main(String[] args) {
        try {
            // Crear un libro de recetas
            LibroDeRecetas<Receta> libro = new LibroDeRecetas<>();
            libro.agregar(new Receta(1, "Tarta de Verdura", "Abuela Rosa", TipoReceta.VEGETARIANA));
            libro.agregar(new Receta(2, "Pollo al horno", "Juan Pérez", TipoReceta.PLATO_PRINCIPAL));
            libro.agregar(new Receta(3, "Ensalada César", "Laura Ruiz", TipoReceta.ENTRADA));
            libro.agregar(new Receta(4, "Brownie", "Chef Martín", TipoReceta.POSTRE));
            libro.agregar(new Receta(5, "Pan sin gluten", "Lucía Gómez", TipoReceta.SIN_TACC));

            // Mostrar todas las recetas 
            System.out.println("Libro de recetas:");
            libro.paraCadaElemento(r -> System.out.println(r));

            // Filtrar recetas por tipo Entrada 
            System.out.println("\nRecetas Entrada:");
            libro.filtrar(r -> r.getTipo() == TipoReceta.ENTRADA)
                    .forEach(r -> System.out.println(r));

            // Filtrar recetas cuyo nombre contiene "ensalada" 
            System.out.println("\nRecetas que contienen 'tarta':");
            libro.filtrar(r -> r.getNombre().toLowerCase().contains("tarta"))
                    .forEach(r -> System.out.println(r));

            // Ordenar recetas por ID (orden natural) 
            System.out.println("\nRecetas ordenadas por ID:");
            libro.ordenar();
            libro.paraCadaElemento(r -> System.out.println(r));

            // Ordenar recetas por nombre 
            System.out.println("\nRecetas ordenadas por nombre:");
            libro.ordenar((r1, r2) -> r1.getNombre().compareTo(r2.getNombre()));

            // Guardar el libro en archivo binario 
            libro.guardarEnArchivo(RutasArchivos.getPathBinarioString());
            // Cargar el libro desde archivo binario
            LibroDeRecetas<Receta> libroCargado = new LibroDeRecetas<>();
            libroCargado.cargarDesdeArchivo(RutasArchivos.getPathBinarioString());
            System.out.println("\nRecetas cargadas desde archivo binario:");
            libroCargado.paraCadaElemento(r -> System.out.println(r));

            // Guardar el libro en archivo CSV 
            libro.guardarEnCSV(RutasArchivos.getPathCSVString());
            // Cargar el libro desde archivo CSV 
            libroCargado.cargarDesdeCSV(RutasArchivos.getPathCSVString(), linea -> Receta.fromCSV(linea));
            System.out.println("\nRecetas cargadas desde archivo CSV:");
            libroCargado.paraCadaElemento(r -> System.out.println(r));

            // Guardar el libro en archivo JSON
            libro.guardarEnJSON(RutasArchivos.getPathJSONString());

            // Cargar el libro desde archivo JSON
            libroCargado.cargarDesdeJSON(RutasArchivos.getPathJSONString(),Receta[].class);
            System.out.println("\nRecetas cargadas desde archivo JSON:");
            libroCargado.paraCadaElemento(r -> System.out.println(r));
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

}

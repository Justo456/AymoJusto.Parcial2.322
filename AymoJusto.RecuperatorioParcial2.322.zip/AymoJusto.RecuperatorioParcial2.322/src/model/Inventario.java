package model;

import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import repository.CSVSerializable;

public class Inventario<T extends CSVSerializable & Serializable & Comparable<T>> {
    private static final long serialVersionUID = 1L;
    private List<T> elementos = new ArrayList<>();

    public void agregar(T t) {
        elementos.add(t);
    }

    public void eliminar(int index) {
        if (index >= 0 && index < elementos.size()) {
            elementos.remove(index);
        }
    }

    public void paraCadaElemento(Consumer<? super T> accion) {
        for (T t : elementos) {
            accion.accept(t);
        }
    }

    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> resultado = new ArrayList<>();
        for (T t : elementos) {
            if (criterio.test(t)) {
                resultado.add(t);
            }
        }
        return resultado;
    }

    public void transformar(Function<? super T, ? extends T> transformador) {
        for (int i = 0; i < elementos.size(); i++) {
            elementos.set(i, transformador.apply(elementos.get(i)));
        }
    }

    public void ordenar() {
        Collections.sort(elementos);
    }

    public void ordenar(Comparator<? super T> comp) {
        elementos.sort(comp);
    }

    public void guardarEnArchivo(String ruta) throws IOException {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(ruta))) {
            salida.writeObject(elementos);
        }
    }

    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException {
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(ruta))) {
            elementos = (List<T>) entrada.readObject();
        }
    }

    public void guardarEnCSV(String ruta) throws IOException {
        try (PrintWriter salida = new PrintWriter(new FileWriter(ruta))) {
            for (T t : elementos) {
                salida.println(t.toCSV());
            }
        }
    }

    public void cargarDesdeCSV(String ruta, Function<String, T> creadorDesdeLinea) throws IOException {
        elementos.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                T obj = creadorDesdeLinea.apply(linea);
                if (obj != null) {
                    elementos.add(obj);
                }
            }
        }
    }

    public void guardarEnJSON(String path) throws IOException {
        Gson gson = new Gson();
        String json = gson.toJson(elementos);
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            bw.write(json);
        }
    }

    public void cargarDesdeJSON(String path, Class<T[]> arrayType) throws IOException {
        Gson gson = new Gson();
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            T[] arr = gson.fromJson(br, arrayType);
            elementos = new ArrayList<>(Arrays.asList(arr));
        }
    }
}

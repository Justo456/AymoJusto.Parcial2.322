package model;

import java.io.Serializable;
import repository.CSVSerializable;

public class NaveEspacial implements Comparable<NaveEspacial>, CSVSerializable, Serializable {

    private static final long serialVersionUID = 1L;

    private int id;
    private String nombre;
    private String descripcion;
    private Categoria categoria;
    private int capacidadTripulacion;

    public NaveEspacial(int id, String nombre, String descripcion, Categoria categoria, int capacidadTripulacion) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.categoria = categoria;
        this.capacidadTripulacion = capacidadTripulacion;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public int getCapacidadTripulacion() {
        return capacidadTripulacion;
    }

    

    @Override
    public String toString() {
        return "Nave Espacial: " + nombre + " (" + descripcion + ") || " + categoria + " || Tripulación: " + capacidadTripulacion;
    }

    @Override
    public int compareTo(NaveEspacial otra) {
        return Integer.compare(this.id, otra.id); // ✅ ahora ordena por ID
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + descripcion + "," + categoria + "," + capacidadTripulacion;
    }

    public static NaveEspacial fromCSV(String linea) {
        String[] partes = linea.split(",");
        int id = Integer.parseInt(partes[0]);
        String nombre = partes[1];
        String descripcion = partes[2];
        Categoria categoria = Categoria.valueOf(partes[3]);
        int capacidad = Integer.parseInt(partes[4]);
        return new NaveEspacial(id, nombre, descripcion, categoria, capacidad);
    }
}


package model;


public enum Categoria {
    EXPLORACION,
    CARGA,
    MILITAR
}

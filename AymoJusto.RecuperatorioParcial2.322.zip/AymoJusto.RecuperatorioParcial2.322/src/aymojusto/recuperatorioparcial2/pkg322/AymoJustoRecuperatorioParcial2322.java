package aymojusto.recuperatorioparcial2.pkg322;

import config.RutasArchivos;
import java.io.IOException;
import model.Categoria;
import model.Inventario;
import model.NaveEspacial;

public class AymoJustoRecuperatorioParcial2322 {

    public static void main(String[] args) {
        

        try {
            // Crear un inventario de naves espaciales
            Inventario<NaveEspacial> inventarioNaves = new Inventario<>();

            inventarioNaves.agregar(new NaveEspacial(1,"USS Enterprise", "Exploración", Categoria.EXPLORACION,10));
            inventarioNaves.agregar(new NaveEspacial(2,"Millennium Falcon", "Carga y Transporte", Categoria.CARGA,15));
            inventarioNaves.agregar(new NaveEspacial(3,"TIE Fighter", "Combate Espacial", Categoria.MILITAR, 2000));
            inventarioNaves.agregar(new NaveEspacial(4,"X-Wing", "Combate y Reconocimiento", Categoria.MILITAR ,400));
            inventarioNaves.agregar(new NaveEspacial(5,"Discovery One", "Exploración Lejana", Categoria.EXPLORACION, 4));
            inventarioNaves.agregar(new NaveEspacial(6,"Nebulon-B Frigate", "Soporte militar", Categoria.MILITAR, 200));

            // Mostrar todas las naves en el inventario
            System.out.println("Inventario de naves espaciales:");
            inventarioNaves.paraCadaElemento(n -> System.out.println(n));

            // Filtrar naves por categoría MILITAR
            System.out.println("\nNaves de la categoría MILITAR:");
            inventarioNaves.filtrar(n -> n.getCategoria() == Categoria.MILITAR)
                           .forEach(n -> System.out.println(n));

            // Filtrar naves cuyo nombre contiene "Falcon"
            System.out.println("\nNaves cuyo nombre contiene 'Falcon':");
            inventarioNaves.filtrar(n -> n.getNombre().contains("Falcon"))
                           .forEach(n -> System.out.println(n));

            // Ordenar naves de manera natural (por nombre)
            System.out.println("\nNaves ordenadas de manera natural (por nombre):");
            inventarioNaves.ordenar();
            inventarioNaves.paraCadaElemento(n -> System.out.println(n));

            // Ordenar naves por capacidad de tripulación utilizando un Comparator
            System.out.println("\nNaves ordenadas por capacidad de tripulación:");
            inventarioNaves.ordenar((a, b) -> Integer.compare(a.getCapacidadTripulacion(), b.getCapacidadTripulacion()));
            inventarioNaves.paraCadaElemento(n -> System.out.println(n));

            // Guardar el inventario en un archivo binario
            inventarioNaves.guardarEnArchivo(RutasArchivos.getPathBinarioString());

            // Cargar el inventario desde el archivo binario
            Inventario<NaveEspacial> inventarioCargado = new Inventario<>();
            inventarioCargado.cargarDesdeArchivo(RutasArchivos.getPathBinarioString());
            System.out.println("\nNaves cargadas desde archivo binario:");
            inventarioCargado.paraCadaElemento(n -> System.out.println(n));

            // Guardar el inventario en un archivo CSV
            inventarioNaves.guardarEnCSV(RutasArchivos.getPathCSVString());

            // Cargar el inventario desde el archivo CSV
            inventarioCargado.cargarDesdeCSV(RutasArchivos.getPathCSVString(), linea -> NaveEspacial.fromCSV(linea));
            System.out.println("\nNaves cargadas desde archivo CSV:");
            inventarioCargado.paraCadaElemento(n -> System.out.println(n));

            // Guardar el inventario en JSON
            inventarioNaves.guardarEnJSON(RutasArchivos.getPathJSONString());

            // Cargar el inventario desde archivo JSON
            inventarioCargado.cargarDesdeJSON(RutasArchivos.getPathJSONString(), NaveEspacial[].class);
            System.out.println("\nNaves cargadas desde archivo JSON:");
            inventarioCargado.paraCadaElemento(nave -> System.out.println(nave));

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}


    

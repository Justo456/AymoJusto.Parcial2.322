
package config;

import java.nio.file.Path;
import java.nio.file.Paths;


public interface RutasArchivos {
    static final String BASE = "src/resources";
    
    static final String CSV = "nave.csv";
    
    static final String BIN = "nave.bin";
    
    static final String JSON = "nave.json";
    
    
    public static Path getPathCSV(){
        return Paths.get(BASE, CSV);
    }
    
    public static String getPathCSVString(){
        return getPathCSV().toString();
    }
    
    public static Path getPathBinario(){
        return Paths.get(BASE, BIN);
    }
    
    public static String getPathBinarioString(){
        return getPathBinario().toString();
    }  
    public static Path getPathJSON() {
        return Paths.get(BASE, JSON);
    }

    public static String getPathJSONString() {
        return getPathJSON().toString();
    }
}
